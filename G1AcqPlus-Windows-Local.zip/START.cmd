@echo off
setlocal
if not exist "%~dp0Windows-OneClick.ps1" (
    echo Extract all files from the ZIP before running START.cmd.
    pause
    exit /b 2
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Windows-OneClick.ps1"
set "g1_result=%ERRORLEVEL%"
if not "%g1_result%"=="0" pause
exit /b %g1_result%
