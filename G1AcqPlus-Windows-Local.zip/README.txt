﻿Запуск G1 ACQ Plus на Windows

1. Скопируйте ZIP на Windows-ПК и извлеките ВСЕ файлы в одну папку.
2. Запустите START.cmd.
3. Если LDPlayer не установлен, на открывшейся партнёрской
   странице выберите LDPlayer 9 (64-бит, Android 9), установите
   его и вернитесь в скрипт.

Файл Windows-OneClick.ps1 содержит исходники и BillingClient DEX.
Для загрузки Python, зависимостей и эмулятора требуется Интернет.
Спонсор: https://animeyume.online
